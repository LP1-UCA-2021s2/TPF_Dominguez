#ifndef funciones_H_
#define funciones_H_
#include<gtk/gtk.h>
#define MAX_FILA 17
#define MAX_COLUMNA 17
#define TAM_TABLERO 17
#define M 17
GtkWidget *imagenes[17][17];
char tablero[17][17] = {{' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '},
					   {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '},
					   {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '},
					   {' ', ' ', ' ', ' ', ' ', ' ', 'V', ' ', ' ', ' ', 'V', ' ', ' ', ' ', ' ', ' ', ' '},
					   {' ' ,' ', ' ', ' ', 'L', 'V', 'V', ' ', ' ', ' ', 'V', 'V', 'L', ' ', ' ', ' ', ' '},
					   {' ', ' ', 'L', 'V', 'V', 'V', 'V', 'V', 'L', 'V', 'V', 'V', 'V', 'V', 'L', ' ', ' '},
					   {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '},
					   {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '},
					   {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '},
					   {' ', ' ', ' ', ' ', ' ', ' ', 'V', 'L', 'L', 'V', ' ', ' ', ' ', ' ', ' ', ' ', ' '},
					   {' ', ' ', ' ', ' ', ' ', ' ', ' ', 'V', 'L', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '},
					   {' ', ' ', 'B', 'A', 'A', 'A', 'A', 'A', 'B', 'A', 'A', 'A', 'A', 'A', 'B', ' ', ' '},
					   {' ', ' ', ' ', ' ', 'B', 'A', 'A', ' ', ' ', ' ', 'A', 'A', 'B', ' ', ' ', ' ', ' '},
					   {' ' ,' ', ' ', ' ', ' ', ' ', 'A', ' ', ' ', ' ', 'A', ' ', ' ', ' ', ' ', ' ', ' '},
					   {' ' ,' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '},
					   {' ' ,' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '},
					   {' ' ,' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '}};

char tablero1[17][17] ={{'H', 'H', '/', '/', '*', '*', '*', '*', '*', '*', '*', '*', '*', '/', '/', 'P', 'P'},
					   	   {'H', 'H', '/', '/', '*', '*', '*', '*', '*', '*', '*', '*', '*', '/', '/', 'P', 'P'},
						   {'H', 'H', '/', '/', '*', '*', '*', '*', '*', '*', '*', '*', '*', '/', '/', 'P', 'P'},
						   {'H', 'H', '/', '/', '*', '*', '*', '-', '-', '-', '*', '*', '*', '/', '/', 'P', 'P'},
						   {'H' ,'/', '/', '/', '*', '*', '*', '-', '-', '-', '*', '*', '*', '/', '/', 'P', 'P'},
						   {'H', '/', '/', '/', '*', '*', '*', '*', '*', '*', '*', '*', '*', '/', '/', 'P', 'P'},
						   {'H', '/', '/', '/', '*', '*', '*', '*', '*', '*', '*', '*', '*', '/', '/', '/', 'P'},
						   {'H', '/', '/', '/', '*', '*', '*', '*', '*', '*', '*', '*', '*', '/', '/', '/', 'P'},
						   {'H', '/', '/', '/', '*', '*', '*', '*', '*', '*', '*', '*', '*', '/', '/', '/', 'P'},
						   {'H', '/', '/', '/', '*', '*', '*', '*', '*', '*', '*', '*', '*', '/', '/', '/', 'P'},
						   {'H', '/', '/', '/', '*', '*', '*', '*', '*', '*', '*', '*', '*', '/', '/', '/', 'P'},
						   {'H', 'H', '/', '/', '*', '*', '*', '*', '*', '*', '*', '*', '*', '/', '/', '/', 'P'},
						   {'H', 'H', '/', '/', '*', '*', '*', '^', '^', '^', '*', '*', '*', '/', '/', '/', 'P'},
						   {'H' ,'H', '/', '/', '*', '*', '*', '^', '^', '^', '*', '*', '*', '/', '/', 'P', 'P'},
						   {'H' ,'H', '/', '/', '*', '*', '*', '*', '*', '*', '*', '*', '*', '/', '/', 'P', 'P'},
						   {'H' ,'H', '/', '/', '*', '*', '*', '*', '*', '*', '*', '*', '*', '/', '/', 'P', 'P'},
						   {'H' ,'H', '/', '/', '*', '*', '*', '*', '*', '*', '*', '*', '*', '/', '/', 'P', 'P'}};
GtkWidget *crear_tablero();
GtkWidget *eventbox;
//Gtk Ventanas
GtkWidget *ventana_inicio;
GtkWidget *ventana_opciones;
GtkWidget *ventana_tablero;
GtkWidget *ventana_datos;
GtkWidget *ventana_reglas;

	//Gtk botones
//Menu
GtkWidget *bjugar;
GtkWidget *bdatos;
GtkWidget *breglas;
GtkWidget *bsalir;
//Opciones
GtkWidget *bsuffragetto;
GtkWidget *bpolicia;
GtkWidget *baleatorio;
GtkWidget *bjugador;
GtkWidget *bjugador2;
GtkWidget *baleatorio2;
GtkWidget *bplay;
//Datos
GtkWidget *batrasP;
//Reglas
GtkWidget *batrasR;
//Tablero
GtkWidget *batrasT;
GtkWidget *labeljugador;
GtkWidget *labeljugador2;
GtkWidget *labelturno;
GtkWidget *labelestado;

GtkWidget *nomjugador;
GtkWidget *nomjugador2;
const gchar *buffer_1;
const gchar *buffer_2;
gchar *temp;




//Variables globales
int i_f; //Fila de la ficha a mover
int i_c; //Columna de la ficha a mover
int f_f; // Fila de la posicion final
int f_c; // Columna de la posicion final
char menor;//ficha normal jugador
char mayor;//ficha especial jugador

char nombre_jugador1[255], nombre_jugador2[255];

int turno; // Turno de quien empieza
int ficha;
int lleno();
int captura1=0;//capturas del  jugador
int captura2=0;//capturas del cpu
int cont=0;
int cont1=0;//Contador para  HOUSE OF COMMONS
int cont2=0;//Contador para ALBERT HALL
char lobby;
int zonas();
int zonas_2();
int zonas_3();
int coord_inicial();
int coord_final();

//Funciones

void imprimir_tablero();
void sortear_ficha();
void sortear_turno();
void usuario();
void cpu();
void ingresar(char ficha);
void cambio_medio(int a, int b);
void cambio(int a, int b);
void comer();
void mover();
//Funciones GTK
void Bjugar(GtkWidget *widget, gpointer data);
void Bsuffragetto(GtkWidget *widget, gpointer data);
void Bpolicia(GtkWidget *widget, gpointer data);
void BazarF(GtkWidget *widget, gpointer data);
void Busuario(GtkWidget *widget, gpointer data);
void Bcpu(GtkWidget *widget, gpointer data);
void BazarT(GtkWidget *widget, gpointer data);
void Bgo(GtkWidget *widget, gpointer data);
void Bdatos(GtkWidget *widget, gpointer data);
void Breglas(GtkWidget *widget, gpointer data);
void BatrasP(GtkWidget *widget, gpointer data);
void BatrasR(GtkWidget *widget, gpointer data);
void BatrasT(GtkWidget *widget, gpointer data);
void Bsalir(GtkWidget *widget, gpointer data);

void clicked_jugar(GtkWidget *widget, gpointer data);
void clicked_suffragetto(GtkWidget *widget, gpointer data);
void clicked_policia(GtkWidget *widget, gpointer data);
void clicked_azarF(GtkWidget *widget, gpointer data);
void clicked_usuario(GtkWidget *widget, gpointer data);
void clicked_cpu(GtkWidget *widget, gpointer data);
void clicked_azarT(GtkWidget *widget, gpointer data);
void clicked_go(GtkWidget *widget, gpointer data);
void clicked_datos(GtkWidget *widget, gpointer data);
void clicked_reglas(GtkWidget *widget, gpointer data);
void clicked_atrasP(GtkWidget *widget, gpointer data);
void clicked_atrasR(GtkWidget *widget, gpointer data);
void clicked_atrasT(GtkWidget *widget, gpointer data);
void clicked_salir(GtkWidget *widget, gpointer data);
#endif /* funciones_H_ */
