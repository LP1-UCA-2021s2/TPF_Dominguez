#include "funciones.h"
#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#define MAX_FILA 17
GtkWidget *label_estado;
#define MAX_COLUMNA 17

GtkWidget *label_turno;
GtkWidget *Tablero;
int lleno(){
	GtkWidget *dialog_ganoS,*dialog_ganoP;
	int i,j;
	/*
	 	 * En ambos casos el contador empieza en 6, y cada vez que hay una pieza distinta a ^ o /
	 	 * disminuye uno, el primero que llega a 0 gana
	*/

	for (i=3; i<=4; i++){
		for (j=7; j<=9; j++){
			if(tablero[i][j]!=' '){
				cont1++;
			}
		}
	}
	for(i=12; i<=13; i++){
		for (j=7; j<=9; j++){
			if (tablero[i][j]!=' '){
				cont2++;
			}
		}
	}

	if (cont2==6){
		g_print("\nGANARON LOS SUFFRAGETOS!\n");
		dialog_ganoS = gtk_message_dialog_new(GTK_WINDOW(ventana_tablero),
																												GTK_DIALOG_DESTROY_WITH_PARENT, GTK_MESSAGE_ERROR,
																								GTK_BUTTONS_OK, "GANARON LOS SUFFRAGETOS!");
								if(gtk_dialog_run(GTK_DIALOG(dialog_ganoS) ) == GTK_RESPONSE_OK)
								   gtk_widget_destroy(GTK_WIDGET(dialog_ganoS) );
									gtk_widget_show_all (ventana_inicio);
									gtk_widget_hide(ventana_tablero);
		return 0;
	}
	else if(cont1==6){
		g_print("\nGANARON LOS POLICIAS!\n");
		dialog_ganoP = gtk_message_dialog_new(GTK_WINDOW(ventana_tablero),
																														GTK_DIALOG_DESTROY_WITH_PARENT, GTK_MESSAGE_ERROR,
																										GTK_BUTTONS_OK, "GANARON LOS POLICIAS!");
										if(gtk_dialog_run(GTK_DIALOG(dialog_ganoP) ) == GTK_RESPONSE_OK)
										   gtk_widget_destroy(GTK_WIDGET(dialog_ganoP) );
											gtk_widget_show_all (ventana_inicio);
											gtk_widget_hide(ventana_tablero);
		return 0;
	}
	else{
		return 1;
	}
}

void tablero_cb(GtkWidget *event_box, GdkEventButton *event, gpointer data) {
	GtkWidget *dialog_error,*dialog_error2;
	guint i,j;
	i = (GUINT_FROM_LE(event->y) / 34); //las imagenes tienen son 34x34pixeles
	j= (GUINT_FROM_LE(event->x) / 34);
	if(lleno()){

		if(turno==0){
			temp = g_strdup_printf("Jugador");
			gtk_label_set_text(GTK_LABEL(label_turno), temp);
			if (cont==0)
			{
				i_f = i;
				i_c = j;
				gchar *temp = g_strdup_printf("Presiono la imagen coordenada [%d,%d]", i,j);
				gtk_label_set_text(GTK_LABEL(label_estado), temp);
				if(!coord_inicial()){
					cont=1;
					turno = 0;
				}
				else{
					dialog_error2 = gtk_message_dialog_new(GTK_WINDOW(ventana_tablero),
																										GTK_DIALOG_DESTROY_WITH_PARENT, GTK_MESSAGE_ERROR,
																						GTK_BUTTONS_OK, "ERROR, NO SELECCIONASTE BIEN !!!");
						if(gtk_dialog_run(GTK_DIALOG(dialog_error2) ) == GTK_RESPONSE_OK)
						   gtk_widget_destroy(GTK_WIDGET(dialog_error2) );
					cont = 0;
				}
				g_print("EL VALOR INICIAL : %d-%d\n", i, j);
			}
			else if(cont==1){
				f_f = i;
				f_c = j;
				g_print("EL VALOR FINAL%d-%d\n", i, j);
				gchar *temp = g_strdup_printf("Presiono la imagen coordenada [%d,%d]", i,j);
				gtk_label_set_text(GTK_LABEL(label_estado), temp);
				if(!coord_final()){
					cont = 0;
					turno = 1;
					imprimir_tablero();
				}
				else{
					dialog_error = gtk_message_dialog_new(GTK_WINDOW(ventana_tablero),
																								GTK_DIALOG_DESTROY_WITH_PARENT, GTK_MESSAGE_ERROR,
																				GTK_BUTTONS_OK, "ERROR JUGADA NO VALIDA !!!");
					if(gtk_dialog_run(GTK_DIALOG(dialog_error) ) == GTK_RESPONSE_OK)
						gtk_widget_destroy(GTK_WIDGET(dialog_error) );
					cont=1;
					turno = 0;
				}
			}
		}
		if (turno == 1){
			temp = g_strdup_printf("CPU");
			gtk_label_set_text(GTK_LABEL(label_turno), temp);
			cpu();
		}
	}
	else if(lleno()==1){
		g_print("\nGANARON LOS POLICIAS!\n");
	}
	else if(lleno()==1){
		g_print("\nGANARON LOS SUFFRAGETOS!\n");
	}
	g_free(temp);
}

GtkWidget *crear_tablero(){
	int i, j;
	//GtkWidget *imagenes; //auxiliar para cargar la imagen
	GtkWidget *eventbox;
	eventbox = gtk_event_box_new();
	Tablero= gtk_grid_new();
	for (i = 0; i < MAX_FILA; i++) {
		for (j = 0; j < MAX_COLUMNA; j++) {
			if(tablero1[i][j]=='H' || tablero1[i][j]=='P'){
				imagenes[i][j] = gtk_image_new_from_file("./IMG/carcel-vacia.jpg");
			}
			if(tablero1[i][j]=='/'){
				imagenes[i][j] = gtk_image_new_from_file("/IMG/on-arena.jpg");
			}
			if(tablero1[i][j]=='*'){
				imagenes[i][j] = gtk_image_new_from_file("/IMG/no-arena.jpg");
			}
			if (tablero1[i][j]=='^' || tablero1[i][j]=='-'){
				imagenes[i][j] = gtk_image_new_from_file("/IMG/hospital-vacio.jpg");
			}
			//imagenes fichas suffragettto
			if(tablero[i][j]=='V' && tablero1[i][j]=='*'){
				imagenes[i][j] = gtk_image_new_from_file("/IMG/suffr-off_arena.jpg");
			}
			if(tablero[i][j]=='L' && tablero1[i][j]=='*'){
				imagenes[i][j] = gtk_image_new_from_file("/IMG/lider-off_arena.jpg");
			}
			if(tablero[i][j]=='V' && tablero1[i][j]=='/'){
				imagenes[i][j] = gtk_image_new_from_file("/IMG/suffr-off_arena.jpg");
			}
			if(tablero[i][j]=='L' && tablero1[i][j]=='/'){
				imagenes[i][j]= gtk_image_new_from_file("/IMG/lider-off_arena.jpg");
			}
			//imagenes fichas policia
			if(tablero[i][j]=='A' && tablero1[i][j]=='*'){
				imagenes[i][j] = gtk_image_new_from_file("/IMG/policia-on_arena.jpg");
			}
			if(tablero[i][j]=='B' && tablero1[i][j]=='*'){
				imagenes[i][j] = gtk_image_new_from_file("/IMG/inpsector-on_arena.jpg");
			}
			if(tablero[i][j]=='A' && tablero1[i][j]=='/'){
				imagenes[i][j] = gtk_image_new_from_file("/IMG/policia-off_arena.jpg");
			}
			if(tablero[i][j]=='B' && tablero1[i][j]=='/'){
				imagenes[i][j] = gtk_image_new_from_file("/IMG/inspector_-off_arena.jpg");
			}

			gtk_grid_attach(GTK_GRID(tablero), GTK_WIDGET(imagenes[i][j]), j, i, 1, 1);
		}
	}
	gtk_container_add(GTK_CONTAINER(eventbox), Tablero);
	g_signal_connect(eventbox, "button-press-event", G_CALLBACK(tablero_cb), tablero);
	return eventbox;
}
int main(int argc, char *argv[]) {
	GtkWidget *box_tablero;

	//Para el GtkBuilder
	guint ret;
	GtkBuilder *builder;
	GError *error = NULL;

	gtk_init(&argc, &argv);

	builder = gtk_builder_new();
	//Se carga el builder
	ret = gtk_builder_add_from_file(builder, "sufraguetto.glade", &error);
	if (ret == 0) {
		g_print("Error en la función gtk_builder_add_from_file:\n%s",
				error->message);
		return 1;
	}

	//Ventanas
	ventana_inicio = GTK_WIDGET(gtk_builder_get_object(builder, "window_menu"));
	ventana_opciones = GTK_WIDGET(gtk_builder_get_object(builder, "window_opciones"));
	ventana_datos = GTK_WIDGET(gtk_builder_get_object(builder, "window_datos"));
	ventana_reglas = GTK_WIDGET(gtk_builder_get_object(builder, "window_reglas"));
	ventana_tablero = GTK_WIDGET(gtk_builder_get_object(builder, "ventana"));


	//Box donde estara el Tablero
	box_tablero = GTK_WIDGET(gtk_builder_get_object(builder, "box_tablero"));

	batrasT = GTK_WIDGET(gtk_builder_get_object(builder, "button_atrasT"));
	g_signal_connect(batrasT, "clicked", G_CALLBACK(clicked_atrasT), NULL);

//	Labels
	label_turno = GTK_WIDGET(gtk_builder_get_object(builder, "label_turno"));
	label_estado = GTK_WIDGET(gtk_builder_get_object(builder, "label_estado"));

	//Botones
	bjugar = GTK_WIDGET(gtk_builder_get_object(builder, "button_jugar"));
	g_signal_connect(bjugar, "clicked", G_CALLBACK(clicked_jugar), NULL);

	bsuffragetto = GTK_WIDGET(gtk_builder_get_object(builder, "button_suffragetto"));
	g_signal_connect(bsuffragetto, "clicked", G_CALLBACK(clicked_suffragetto), NULL);

	bpolicia = GTK_WIDGET(gtk_builder_get_object(builder, "button_policia"));
	g_signal_connect(bpolicia, "clicked", G_CALLBACK(clicked_policia), NULL);

	baleatorio = GTK_WIDGET(gtk_builder_get_object(builder, "button_azarF"));
	g_signal_connect(baleatorio, "clicked", G_CALLBACK(clicked_azarF), NULL);

	bjugador = GTK_WIDGET(gtk_builder_get_object(builder, "button_usuario"));
	g_signal_connect(bjugador, "clicked", G_CALLBACK(clicked_usuario), NULL);

	bjugador2 = GTK_WIDGET(gtk_builder_get_object(builder, "button_cpu"));
	g_signal_connect(bjugador2, "clicked", G_CALLBACK(clicked_cpu), NULL);

	baleatorio = GTK_WIDGET(gtk_builder_get_object(builder, "button_azarT"));
	g_signal_connect(baleatorio, "clicked", G_CALLBACK(clicked_azarT), NULL);

	bplay = GTK_WIDGET(gtk_builder_get_object(builder, "button_go"));
	g_signal_connect(bplay, "clicked", G_CALLBACK(clicked_go), NULL);

	//Boton datos
	bdatos = GTK_WIDGET(gtk_builder_get_object(builder, "button_datos"));
	g_signal_connect(bdatos, "clicked", G_CALLBACK(clicked_datos), NULL);

	batrasP = GTK_WIDGET(gtk_builder_get_object(builder, "button_atrasP"));
	g_signal_connect(batrasP, "clicked", G_CALLBACK(clicked_atrasP), NULL);

	//Boton reglas
	breglas = GTK_WIDGET(gtk_builder_get_object(builder, "button_reglas"));
	g_signal_connect(breglas, "clicked", G_CALLBACK(clicked_reglas), NULL);

	batrasR = GTK_WIDGET(gtk_builder_get_object(builder, "button_atrasR"));
	g_signal_connect(batrasR, "clicked", G_CALLBACK(clicked_atrasR), NULL);

	//salir
	bsalir = GTK_WIDGET(gtk_builder_get_object(builder, "button_salir"));
	g_signal_connect(bsalir, "clicked", G_CALLBACK (gtk_main_quit), NULL);

	labeljugador = GTK_WIDGET(gtk_builder_get_object(builder, "label_usuario"));
	labeljugador2 = GTK_WIDGET(gtk_builder_get_object(builder, "label_cpu"));


	nomjugador = GTK_WIDGET(gtk_builder_get_object(builder, "nom_usuario"));
	nomjugador2 = GTK_WIDGET(gtk_builder_get_object(builder, "nom_cpu"));
	temp = GTK_WIDGET(gtk_builder_get_object(builder, "temp"));
	gtk_box_pack_start(GTK_BOX(box_tablero), crear_tablero(), TRUE, FALSE, 20);

	/* Connect the destroy signal of the window to gtk_main_quit
	 * When the window is about to be destroyed we get a notification and
	 * stop the main GTK+ loop
	 */
	g_signal_connect(ventana_inicio, "destroy", G_CALLBACK (gtk_main_quit), NULL);
	g_signal_connect(ventana_opciones, "destroy", G_CALLBACK (gtk_main_quit), NULL);
	g_signal_connect(ventana_reglas, "destroy", G_CALLBACK (gtk_main_quit), NULL);
	g_signal_connect(ventana_datos, "destroy", G_CALLBACK (gtk_main_quit), NULL);
	g_signal_connect(ventana_tablero, "destroy", G_CALLBACK (gtk_main_quit), NULL);


	/* make sure that everything, window and label, are visible */
	gtk_widget_show_all(ventana_inicio);

	/* start the main loop, and let it rest there until the application is closed */
	gtk_main();


	return 0;
}

int coord_inicial(){
    if(ficha==0 && turno==0){
       	 mayor = 'L';
		 menor = 'V';
		 lobby = '^';
    }
     if(ficha==0 && turno==1){
		 mayor = 'B';
		 menor = 'A';
		 lobby = '-';
	}
	if(ficha==1 && turno==1){
		mayor = 'L';
		menor = 'V';
		lobby = '^';
    }
    if(ficha==1 && turno==0){
    	mayor = 'B';
		menor = 'A';
		lobby = '-';
    }

    if (i_f>17 || i_c>17 || i_f<0 || i_c<0) return 1;

    if (tablero1[i_f][i_c]=='H' || tablero1[i_f][i_c]=='P') return 1;

    if (tablero[i_f][i_c]==mayor || tablero[i_f][i_c]==menor)
    {
        return 0;
    }
    else
    {
        return 1;
    }
    return 0;
}

int coord_final(){
    int restaF, restaC;
    restaF = abs(f_f - i_f);
    restaC = abs(f_c - i_c);

    if (f_f>17 || f_c>17 || f_f<0 || f_c<0) return 1;

    if (tablero[f_f][f_c]!=' ') return 1;

    if (tablero1[i_f][i_c]==lobby && tablero1[f_f][f_c]!=lobby) return 1;

    if((tablero[i_f][i_c]=='V' || tablero[i_f][i_c]=='L') && tablero1[f_f][f_c]=='-' ) return 1;

    if((tablero[i_f][i_c]=='A' || tablero[i_f][i_c]=='B') && tablero1[f_f][f_c]=='^' ) return 1;

    if ((restaF==0 && restaC==1) || (restaF==1 && restaC==0) || (restaF==1 && restaC==1)){
        mover();
        return 0;
    }
    if ((restaF==0 && restaC==2) || (restaF==2 && restaC==0) || (restaF==2 && restaC==2)){
    	if(tablero[(i_f+f_f)/2][(i_c+f_c)/2]==' ') return 1;
        if(tablero[(i_f+f_f)/2][(i_c+f_c)/2]==mayor || tablero[(i_f+f_f)/2][(i_c+f_c)/2]==menor){
            mover();
            return 0;
        }
        else{
            comer();
            return 0;
        }

    }
    return 1;

}

void cpu(){
	do{
		i_f = rand()%17;
		i_c = rand()%17;
		if(!coord_inicial()){
		    break;
		}
	}while(1); //fin do
	do{
		f_f = rand()%17;
		f_c = rand()%17;
		if(!coord_final()){
		    break;
		}
	}while(1);//fin do
	printf("\nLa computadora movio la ficha en  <%d,%d>\n",f_f,f_c);
	turno = 0;
}
/*
    Si la funcion retorna:
        0 esta bien
        1 esta mal
*/

void comer(){
    int restaF, restaC;
    restaF = abs(i_f - f_f);
    restaC = abs(i_c - f_c);
    if (!zonas()){
        if(tablero[i_f][i_c]== mayor){
			if(tablero[(i_f+f_f)/2][(i_c+f_c)/2] == menor || tablero[(i_f+f_f)/2][(i_c+f_c)/2] == mayor){ //verficar si funciona sin espacio en blanco
				tablero[f_f][f_c] = tablero[i_f][f_f];
				tablero[i_f][i_c] = ' ';
				cambio_medio(i_f, i_c);
			}
			else{
				tablero[f_f][f_c] = tablero[i_f][i_c];
				tablero[i_f][i_c] = ' ';
				cambio_medio(i_f, i_c);
				ingresar(tablero[(i_f+f_f)/2][(i_c+f_c)/2]);

				tablero[(i_f+f_f)/2][(i_c+f_c)/2] = ' ';
				cambio_medio((i_f+f_f)/2,(i_c+f_c)/2);
				cambio(f_f,f_c);

			}

	    }
		else {
			if(restaF==2 && restaC==2 && tablero[(i_f+f_f)/2][(i_c+f_c)/2] != mayor &&  tablero[(i_f+f_f)/2][(i_c+f_c)/2] != menor){
				tablero[f_f][f_c] = tablero[i_f][i_c];
				tablero[i_f][i_c] = ' ';
				cambio_medio(i_f, i_c);
				cambio(f_f,f_c);

				ingresar(tablero[(i_f+f_f)/2][(i_c+f_c)/2]);
				tablero[(i_f+f_f)/2][(i_c+f_c)/2] = ' ';
				cambio_medio((i_f+f_f)/2,(i_c+f_c)/2 );
			}
			else{
				tablero[f_f][f_c] = tablero[i_f][i_c];
				tablero[i_f][i_c] = ' ';
				cambio_medio((i_f),(i_c));
				cambio(f_f,f_c);
			}
		}
    }
    if(!zonas_3()){
    	g_print("Entro");
    	if(tablero[(i_f+f_f)/2][(i_c+f_c)/2] != ' '){
			tablero[f_f][f_c] = tablero[i_f][i_c];
			tablero[i_f][i_c] = ' ';
			cambio_medio(i_f, i_c);
			cambio(f_f,f_c);
		}
    }
}

int zonas(){
    if(tablero1[i_f][i_c]=='*' && tablero1[f_f][f_c]=='*'){
        return 0;
    }
    if(tablero1[i_f][i_c]=='/' && tablero1[f_f][f_c]=='*'){
        return 0;
    }
    if(tablero1[i_f][i_c]=='*' && tablero1[f_f][f_c]=='-'){
        return 0;
    }
    if(tablero1[i_f][i_c]=='*' && tablero1[f_f][f_c]=='^'){
        return 0;
    }
    return 1;
}

int zonas_2(){
    if(tablero1[i_f][i_c]=='*' && tablero1[f_f][f_c]=='*'){ //arena a arena
        return 0;
    }
    if(tablero1[i_f][i_c]=='/' && tablero1[f_f][f_c]=='*'){// patio a arena
        return 0;
    }
    if(tablero1[i_f][i_c]=='*' && tablero1[f_f][f_c]=='/'){//arena a patio
		return 0;
	}
    if(tablero1[i_f][i_c]=='*' && tablero1[f_f][f_c]=='-'){//arena a lobby
        return 0;
    }
    if(tablero1[i_f][i_c]=='*' && tablero1[f_f][f_c]=='^'){ // arena a lobby
        return 0;
    }
    if(tablero1[i_f][i_c]=='/' && tablero1[f_f][f_c]=='/'){//patio a patio
		return 0;
	}
    if(tablero1[i_f][i_c]=='^' && tablero1[f_f][f_c]=='^'){// lobby a lobby
		return 0;
	}
    if(tablero1[i_f][i_c]=='-' && tablero1[f_f][f_c]=='-'){// lobby a lobby
    	return 0;
    }
    return 1;
}

int zonas_3(){
	if(tablero1[i_f][i_c]=='/' && tablero1[f_f][f_c]=='/'){//patio a patio
		return 0;
	}
	 if(tablero1[i_f][i_c]=='*' && tablero1[f_f][f_c]=='/'){//arena a patio
		return 0;
	}
	return 1;
}

void mover(){
    if(!zonas_2()){
        tablero[f_f][f_c] = tablero[i_f][i_c];
		tablero[i_f][i_c] = ' ';
		cambio_medio(i_f, i_c);
		cambio(f_f, f_c);
    }
}

void imprimir_tablero(){
	int i,j;
	int aux;
	aux = 0;
	printf("     	  0   1   2   3   4   5   6   7   8   9  10  11  12  13  14  15  16\n");
	printf("    	+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+\n");
	for(i=0; i<M; i++){
		printf("%d	", aux++);
		for (j=0; j<M; j++){
			(j<16)? printf("| %c ",tablero[i][j]): printf("| %c |",tablero[i][j]);
		}//fin for en j
	printf("\n   	+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+\n");
	}//fin for en i
	printf("     	  0   1   2   3   4   5   6   7   8   9  10  11  12  13  14  15  16");
}

void cambio_medio(int a, int b){

	if (tablero1[a][b]=='/'){
		gtk_image_set_from_file(GTK_IMAGE(imagenes[a][b]),("/IMG/on-arena.jpg"));
	}
	if (tablero1[a][b]=='*'){
		gtk_image_set_from_file(GTK_IMAGE(imagenes[a][b]),("/IMG/no-arena.jpg"));
	}
	if (tablero1[a][b]=='^'){
			gtk_image_set_from_file(GTK_IMAGE(imagenes[a][b]),("/IMG/hospital-vacio.jpg"));
	}
	if (tablero1[a][b]=='-'){
			gtk_image_set_from_file(GTK_IMAGE(imagenes[a][b]),("/IMG/hospital-vacio.jpg"));
	}

}
void cambio(int a, int b){
	if(tablero[a][b]==mayor){
		//suffragetto
		if(mayor=='L'){
			if(tablero1[a][b]=='*'){
				gtk_image_set_from_file(GTK_IMAGE(imagenes[a][b]),"/IMG/lider-on_arena.jpg");
			}
			if(tablero1[a][b]=='^'){
				gtk_image_set_from_file(GTK_IMAGE(imagenes[a][b]),"/IMG/lider-house_of_commons.jpg");
			}
			if(tablero1[a][b]=='/'){
				gtk_image_set_from_file(GTK_IMAGE(imagenes[a][b]),"/IMG/off-arena.jpg");
			}
		}
		//policia
		if(mayor=='B'){
			if(tablero1[a][b]=='*'){
				gtk_image_set_from_file(GTK_IMAGE(imagenes[a][b]),"/IMG/policia-on_arena.jpg");
			}
			if(tablero1[a][b]=='-'){
				gtk_image_set_from_file(GTK_IMAGE(imagenes[a][b]),"/IMG/policia-albert-hall.jpg");
			}
			if(tablero1[a][b]=='/'){
				gtk_image_set_from_file(GTK_IMAGE(imagenes[a][b]),"/IMG/policia-off_arena.jpg");
			}
		}
	}
	if(tablero[a][b]==menor){
		//suffragetto
		if(menor=='V'){
			if(tablero1[a][b]=='*'){
				gtk_image_set_from_file(GTK_IMAGE(imagenes[a][b]),"/IMG/suffr-on_arena.jpg");
			}
			if(tablero1[a][b]=='^'){
				gtk_image_set_from_file(GTK_IMAGE(imagenes[a][b]),"/IMG/suffr-house_of_commons.jpg");
			}
			if(tablero1[a][b]=='/'){
				gtk_image_set_from_file(GTK_IMAGE(imagenes[a][b]),"/IMG/suffr-off_arena.jpg");
			}
		}
		//policia
		if(menor=='A'){
			if(tablero1[a][b]=='*'){
				gtk_image_set_from_file(GTK_IMAGE(imagenes[a][b]),"/IMG/policia-off_arena.jpg");
			}
			if(tablero1[a][b]=='-'){
				gtk_image_set_from_file(GTK_IMAGE(imagenes[a][b]),"/IMG/policia-albert-hall.jpg");
			}
			if(tablero1[f_f][f_c]=='/'){
				gtk_image_set_from_file(GTK_IMAGE(imagenes[a][b]),"/IMG/policia-on_arena.jpg");
			}
		}
	}
}


void ingresar(char ficha){
	if(ficha=='V'){
		if(captura1<17){
			tablero[captura1][0]=ficha;
			gtk_image_set_from_file(GTK_IMAGE(imagenes[captura1][0]),("/IMG/suffr-arrestado.jpg"));

		}
		else{
			tablero[captura1-17][1]=ficha;
			gtk_image_set_from_file(GTK_IMAGE(imagenes[captura1-17][1]),("/IMG/suffr-arrestado.jpg"));
		}
		captura1++;
	}
	if(ficha=='L'){
		if(captura1<17){
			tablero[captura1][0]=ficha;
			gtk_image_set_from_file(GTK_IMAGE(imagenes[captura1][0]),("/IMG/lider-arrestado.jpg"));

		}
		else{
			tablero[captura1-17][1]=ficha;
			gtk_image_set_from_file(GTK_IMAGE(imagenes[captura1-17][16]),("/IMG/lider-arrestado.jpg"));
		}
		captura1++;
	}
	else if(ficha=='A'){
		if(captura2<17){
			tablero[captura2][16]=ficha;
			gtk_image_set_from_file(GTK_IMAGE(imagenes[captura2][16]),("./IMG/policia-herido.png"));
		}
		else{
			tablero[33-captura2][15] = ficha;
			gtk_image_set_from_file(GTK_IMAGE(imagenes[captura2][15]),("./IMG/policia-herido.png"));
		}
		captura2++;
	}
	else if(ficha=='B'){
			if(captura2<17){
				tablero[captura2][16]=ficha;
				gtk_image_set_from_file(GTK_IMAGE(imagenes[captura2][16]),("./IMG/inpsector_herido.png"));
			}
			else{
				tablero[33-captura2][15] = ficha;
				gtk_image_set_from_file(GTK_IMAGE(imagenes[captura2][15]),("./IMG/inpsector_herido.png"));
			}
			captura2++;
		}
}
//Funciones para los botones
//Menu
void Bjugar(GtkWidget *widget, gpointer data) /* BOTON JUGAR DEL MENU PRINCIPAL */
{
	gtk_widget_show_all (ventana_opciones);
	gtk_widget_hide(ventana_inicio);
}
void Bsuffragetto(GtkWidget *widget, gpointer data) /* BOTON ELEGIR SUFFRAGETTO */
{
	ficha = 0;
	g_print("%dS",ficha);
}
void Bpolicia(GtkWidget *widget, gpointer data) /* BOTON ELEGIR POLICIA */
{
	ficha = 1;
	g_print("%dP",ficha);

}
void Baleatorio1(GtkWidget *widget, gpointer data) /* BOTON AZAR */
{
	srand(time(NULL));
	ficha = rand()% 2;
	g_print("%dA",ficha);
}

void Bjugador(GtkWidget *widget, gpointer data) /* BOTON EMPEZAR USUARIOS */
{
	turno = 0;
}

void Bjugador2(GtkWidget *widget, gpointer data) /* BOTON EMPEZAR CPU */
{
	turno = 1;
	g_print("%d\n",turno);
}
void Baleatorio2(GtkWidget *widget, gpointer data) /* BOTON EMPEZAR AZAR */
{
	srand(time(NULL));
	turno = rand()% 2;
	g_print("%d a\n",turno);
}
void Bplay(GtkWidget *widget, gpointer data) /* BOTON JUGAR DEL MENU PRINCIPAL */
{
	buffer_1 = gtk_entry_get_text(GTK_ENTRY(nomjugador));
	buffer_2 = gtk_entry_get_text(GTK_ENTRY(nomjugador2));
	sprintf(nomjugador, "%s", buffer_1);
	sprintf(nomjugador2, "%s", buffer_2);
	gtk_label_set_text(GTK_LABEL(labeljugador), nomjugador);
	gtk_label_set_text(GTK_LABEL(labeljugador2), nomjugador2);

	gtk_widget_show_all (ventana_tablero);
	gtk_widget_hide(ventana_opciones);
}

void Bdatos(GtkWidget *widget, gpointer data) /* BOTON JUGAR DEL MENU PRINCIPAL */
{
	gtk_widget_show_all (ventana_datos);
	gtk_widget_hide(ventana_inicio);
}
void BatrasP(GtkWidget *widget, gpointer data) /* BOTON JUGAR DEL MENU PRINCIPAL */
{
	gtk_widget_show_all (ventana_inicio);
	gtk_widget_hide(ventana_datos);
}
void BatrasT(GtkWidget *widget, gpointer data) /* BOTON JUGAR DEL MENU PRINCIPAL */
{
	gtk_widget_show_all (ventana_inicio);
	gtk_widget_hide(ventana_tablero);
}
void Breglas(GtkWidget *widget, gpointer data) /* BOTON JUGAR DEL MENU PRINCIPAL */
{
	gtk_widget_show_all (ventana_reglas);
	gtk_widget_hide(ventana_inicio);
}
void BatrasR(GtkWidget *widget, gpointer data) /* BOTON JUGAR DEL MENU PRINCIPAL */
{
	gtk_widget_show_all (ventana_inicio);
	gtk_widget_hide(ventana_reglas);
}
void clicked_jugar(GtkWidget *widget, gpointer data) /* BOTON JUGAR DEL MENU PRINCIPAL */
{
	gtk_widget_show_all (ventana_opciones);
	gtk_widget_hide(ventana_inicio);
}
void clicked_suffragetto(GtkWidget *widget, gpointer data) /* BOTON ELEGIR SUFFRAGETTO */
{
	ficha = 0;
	g_print("%dS",ficha);
}
void clicked_policia(GtkWidget *widget, gpointer data) /* BOTON ELEGIR POLICIA */
{
	ficha = 1;
	g_print("%dP",ficha);

}
void clicked_azarF(GtkWidget *widget, gpointer data) /* BOTON AZAR */
{
	srand(time(NULL));
	ficha = rand()% 2;
	g_print("%dA",ficha);
}

void clicked_usuario(GtkWidget *widget, gpointer data) /* BOTON EMPEZAR USUARIOS */
{
	turno = 0;
}

void clicked_cpu(GtkWidget *widget, gpointer data) /* BOTON EMPEZAR CPU */
{
	turno = 1;
	g_print("%d\n",turno);
}
void clicked_azarT(GtkWidget *widget, gpointer data) /* BOTON EMPEZAR AZAR */
{
	srand(time(NULL));
	turno = rand()% 2;
	g_print("%d a\n",turno);
}
void clicked_go(GtkWidget *widget, gpointer data) /* BOTON JUGAR DEL MENU PRINCIPAL */
{
	buffer_1 = gtk_entry_get_text(GTK_ENTRY(nomjugador));
	buffer_2 = gtk_entry_get_text(GTK_ENTRY(nomjugador2));
	sprintf(nomjugador, "%s", buffer_1);
	sprintf(nomjugador2, "%s", buffer_2);
	gtk_label_set_text(GTK_LABEL(labeljugador), nomjugador);
	gtk_label_set_text(GTK_LABEL(labeljugador2), nomjugador2);

	gtk_widget_show_all (ventana_tablero);
	gtk_widget_hide(ventana_opciones);
}

void clicked_datos(GtkWidget *widget, gpointer data) /* BOTON JUGAR DEL MENU PRINCIPAL */
{
	gtk_widget_show_all (ventana_datos);
	gtk_widget_hide(ventana_inicio);
}
void clicked_atrasP(GtkWidget *widget, gpointer data) /* BOTON JUGAR DEL MENU PRINCIPAL */
{
	gtk_widget_show_all (ventana_inicio);
	gtk_widget_hide(ventana_datos);
}
void clicked_atrasT(GtkWidget *widget, gpointer data) /* BOTON JUGAR DEL MENU PRINCIPAL */
{
	gtk_widget_show_all (ventana_inicio);
	gtk_widget_hide(ventana_tablero);
}
void clicked_reglas(GtkWidget *widget, gpointer data) /* BOTON JUGAR DEL MENU PRINCIPAL */
{
	gtk_widget_show_all (ventana_reglas);
	gtk_widget_hide(ventana_inicio);
}
void clicked_atrasR(GtkWidget *widget, gpointer data) /* BOTON JUGAR DEL MENU PRINCIPAL */
{
	gtk_widget_show_all (ventana_inicio);
	gtk_widget_hide(ventana_reglas);
}
